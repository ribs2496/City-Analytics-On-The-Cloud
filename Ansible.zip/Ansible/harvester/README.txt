The harvester playbook deploys any harvester application on a required end point.

To deploy:

Include the required server IP in the hosts file and run-harvester.sh script 

