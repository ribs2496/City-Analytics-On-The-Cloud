This playbook configures 3 nodes in a cluster.

Run the dbrun.sh script. Ensure that read access is given to keys before running the script.(chmod 400 Node1-key.pem and chmod 400 Node1-key.ppk)