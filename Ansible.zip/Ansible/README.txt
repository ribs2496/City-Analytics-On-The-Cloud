
1. The deploy playbook creates 4 nodes and covers the basic configurations and software installations

2. The CouchDB Cluster playbook installs CouchDB on to the cluster nodes and adds nodes to the cluster

3. The harvester playbook deploys the harvester application on to a selected end point among the cluster nodes

The OpenStackAPI password for the project:
MWM1MjVhNmYyNTEyMWQx