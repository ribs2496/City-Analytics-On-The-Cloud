#Team 58, Nitika Malhotra (1037082), Anupama Mampage(1102749), Ribhav Shridhar (1037144), Ronak Arvindkumar (1043591)
 
from tweepy import OAuthHandler
import tweepy
import json
import argparse
import couchdb
from tweepy.parsers import JSONParser


if __name__ == '__main__':
    parser = argparse.ArgumentParser()   #To parse the command line arguments
    parser.add_argument('--ip')
    parser.add_argument('--port', type=int, default=80)
    parser.add_argument('--config')      #Config file for Search keywords, and tweepy credentials
    args = parser.parse_args()

    with open(args.config) as conf:      #To load the config file as JSON
        Config = json.load(conf)

    auth = OAuthHandler(Config['consumerKey'], Config['consumerSecret'])   #Authentication for twitter API
    auth.set_access_token(Config['accessToken'], Config['accessTokenSecret'])
    api = tweepy.API(auth, parser=tweepy.parsers.JSONParser())

    url = "http://" + Config['userName'] + ":" + Config['passWord'] + "@" + str(ip) + ":" + str(port)    #URL for couchdb node
    couch = couchdb.Server(url)
    database = couch[Config['dbName']]

    location = str(Config['latitude'])+","+str(Config['longitude'])+",5km"    #Centroid coordinates for searching tweets and its radius

    searchKeyword = Config['searchKeywords']

    for i in range(0,len(searchKeyword)):
    searchQuery = searchKeyword[i]+"-filter:retweets"    #Pick key words from keywords list given in the config file and filter for retweets
    
    tweets = api.search(q= searchQuery, geocode=location,count = 100, lang = "en")
    for key,value in tweets.items():
        if key == "statuses":
            for i in value:
                i["_id"] = i["id_str"]
                try:
                    database.save(i)      #Saving tweet in tweets database
                except:
                    pass