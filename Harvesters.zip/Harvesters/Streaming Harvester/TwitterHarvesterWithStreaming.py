import json
import couchdb
import argparse
from tweepy import OAuthHandler
from tweepy.streaming import StreamListener
from tweepy import Stream


class TweetStreamHarvester(StreamListener):
    def __init__(self, ip, port):
        self.ip = ip
        self.port = port
        self.url = "http://" + Config['userName'] + ":" + Config['passWord'] + "@" + str(self.ip) + ":" + str(
            self.port)

    def on_data(self, data):
        if self.ip:
            try:
                json_o = json.loads(data)
                couch = couchdb.Server(self.url)
                database = couch[Config['dbName']]
                json_o['_id'] = json_o['id_str']
                database.save(json_o)
 
            except:
                print("An error occurred while processing tweet.")
        return True

    def on_error(self, status):
        print("Error")
        return True

    def on_timeout(self):
        # Allow continuation after timeout period lapses
        return True


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--ip')
    parser.add_argument('--port', type=int, default=80)
    parser.add_argument('--config')
    args = parser.parse_args()

    with open(args.config) as conf:
        Config = json.load(conf)

    harvester = TweetStreamHarvester(args.ip, args.port)
    auth = OAuthHandler(Config['consumerKey'], Config['consumerSecret'])
    auth.set_access_token(Config['accessToken'], Config['accessTokenSecret'])

    boundingBox = [Config['longitude1'], Config['latitude1'], Config['longitude2'], Config['latitude2']]
    stream = Stream(auth, harvester)
    stream.filter(locations=boundingBox)
